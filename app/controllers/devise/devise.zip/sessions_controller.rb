class Devise::SessionsController < DeviseController
  prepend_before_filter :require_no_authentication, :only => [ :new, :create ]
  prepend_before_filter :allow_params_authentication!, :only => :create

  layout 'user'
  # GET /resource/sign_in
  def new
    if request.referer.present? and request.referer.split('/').last != "sign_in" and params[:os].blank?
      session[:return_to] = request.referer
    else
      if params[:os]
        session[:return_to] = checkout_login_path
      end
    end
    @cart = current_cart
    @home_sliders = HomeSlider.find(:all, :order => 'preference_no DESC')
    self.resource = resource_class.new(sign_in_params)
    clean_up_passwords(resource)
    #respond_with(resource, serialize_options(resource))
    redirect_to checkout_login_path, :flash => { :error => 'Enter valid email or password' } 
  end

  # POST /resource/sign_in
  def create
    self.resource = warden.authenticate(auth_options) 
    if self.resource.present?
      set_flash_message(:notice, :signed_in) if is_flashing_format?
      sign_in(resource_name, resource)
      yield resource if block_given?
    end
    # respond_with resource, location: after_sign_in_path_for(resource)

    # self.resource = resource_class.new(sign_in_params)
    # @banners = HomeSlider.all.order("preference_no Asc").group_by(&:banner_type)
    # @classifications = Classification.all.order("sequence_no Asc").group_by(&:classification_type)
    # @designers = Designer.all
    # binding.pry
    # if params[:user][:email].present?
    #   if params[:have_account].present? &&  params[:have_account] == "true"
    #     if request.referer.present? and request.referer.split('/').last != "sign_in" and params[:os].blank?
    #       session[:return_to] = request.referer
    #     end
    #     @dum_user = User.find_by_email(params[:user][:email]) rescue nil

    #     if params[:have_account].present? && params[:have_account] == 'true' && (@dum_user.blank? or (@dum_user.present? and not @dum_user.valid_password?(params[:user][:password])))
    #       if params[:ch_out].present? && params[:ch_out] == 'true'
    #         redirect_to checkout_login_path
    #       else
    #         @cart = current_cart
            
    #         # session["login_error"] = "Incorrect email/password"
    #         # render 'home/index'
    #       end

    #     else      
    #       @cart = current_cart
    #       resource = warden.authenticate!(auth_options)
    #       set_flash_message(:notice, :signed_in) if is_navigational_format?
    #       sign_in(resource_name, resource)
    #       # respond_with resource, :location => after_sign_in_path_for(resource)
    #     end
    #   else
    #     redirect_to guest_user_path(:email=>params[:user][:email], :os => true, :commit=> "Continue As Guest")
    #   end
    
    #   #    @home_sliders = HomeSlider.find(:all, :order => 'preference_no DESC')
    #   #    if params[:controller] == "devise/sessions" and !current_user
    #   #      render 'home/index'
    #   #      if session[:return_controller].present? and session[:return_action].present?
    #   #        render session[:return_controller]+"/"+session[:return_action]
    #   #      else
    #   #        render 'home/index'
    #   #      end
    #   #    else
    #   #      resource = warden.authenticate!(auth_options)
    #   #      set_flash_message(:notice, :signed_in) if is_navigational_format?
    #    #     sign_in(resource_name, resource)
    #    #     respond_with resource, :location => after_sign_in_path_for(resource)
    #    #   end
    # else
    #   #redirect_to :back
    #   render 'home/index'
    # end
  end

  # DELETE /resource/sign_out
  def destroy
    @cart = current_cart
    redirect_path = after_sign_out_path_for(resource_name)
    signed_out = (Devise.sign_out_all_scopes ? sign_out : sign_out(resource_name))
    set_flash_message :notice, :signed_out if signed_out

    # We actually need to hardcode this as Rails default responder doesn't
    # support returning empty response on GET request
    respond_to do |format|
      format.any(*navigational_formats) { redirect_to redirect_path }
      format.all do
        method = "to_#{request_format}"
        text = {}.respond_to?(method) ? {}.send(method) : ""
        render :text => text, :status => :ok
      end
    end
  end

  protected

  def serialize_options(resource)
    methods = resource_class.authentication_keys.dup
    methods = methods.keys if methods.is_a?(Hash)
    methods << :password if resource.respond_to?(:password)
    { :methods => methods, :only => [:password] }
  end

  def auth_options
    { :scope => resource_name, :recall => "#{controller_path}#new" }
  end

  def sign_in_params
    devise_parameter_sanitizer.sanitize(:sign_in) do |u|
      u.permit(:email, :password)
    end
  end
end
