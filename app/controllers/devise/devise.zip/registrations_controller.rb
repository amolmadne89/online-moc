class Devise::RegistrationsController < DeviseController
  layout "user"
  prepend_before_filter :require_no_authentication, :only => [ :new, :create, :cancel ]
  prepend_before_filter :authenticate_scope!, :only => [:edit, :update, :destroy]

  # GET /resource/sign_up
  def new
    @cart = current_cart
    resource = build_resource({})
    respond_with resource
  end

  # POST /resource
  def create
    build_resource(sign_up_params)
    resource_saved = resource.save
    yield resource if block_given?
    if resource_saved
      if resource.active_for_authentication?
        set_flash_message :notice, :signed_up if is_flashing_format?
        sign_up(resource_name, resource)
        # respond_with resource, location: after_sign_up_path_for(resource)
      else
        set_flash_message :notice, :"signed_up_but_#{resource.inactive_message}" if is_flashing_format?
        expire_data_after_sign_in!
        # respond_with resource, location: after_inactive_sign_up_path_for(resource)
      end
    else
      clean_up_passwords resource
      @validatable = devise_mapping.validatable?
      if @validatable
        @minimum_password_length = resource_class.password_length.min
      end
      # respond_with resource
    end
#     @cart = current_cart
#     @banners = HomeSlider.all.order("preference_no Asc").group_by(&:banner_type)
#     @classifications = Classification.all.order("sequence_no Asc").group_by(&:classification_type)
#     @designers = Designer.all
#     build_resource(sign_up_params)
#     #raise simple_captcha_valid?.to_yaml
#     if resource.valid? #&& simple_captcha_valid?  #&& verify_recaptcha(:model => resource, :message => "It's error with CAPTCHA!")
#       resource.refer_value = session[:refer]
#       resource.save
#       session[:first_time]= true
#       if resource.active_for_authentication?
#         set_flash_message :notice, :signed_up if is_navigational_format?
#         sign_in(resource_name, resource)
#         respond_with resource, :location => after_sign_up_path_for(resource)
#       else
#         set_flash_message :notice, :"signed_up_but_#{resource.inactive_message}" if is_navigational_format?
#         expire_session_data_after_sign_in!
#         respond_with resource, :location => after_inactive_sign_up_path_for(resource)
#       end
#     else
#       logger.info resource.errors.inspect
#       #clean_up_passwords resource
#       #respond_with resource
#       render 'home/index'
# #      if session[:return_controller].present? and session[:return_action].present?
# #        render session[:return_controller]+"/"+session[:return_action]
# #      else
# #        render 'home/index'
# #      end
#     end
  end


  def clean_up_passwords(*args)
    # Delete or comment out this method to prevent the password fields from
    # repopulating after a failed registration
  end

  # GET /resource/edit
  def edit
    @cart = current_cart
    render :edit
  end

  # PUT /resource
  # We need to use a copy of the resource because we don't want to change
  # the current user in place.
  def update
    @cart = current_cart
    self.resource = resource_class.to_adapter.get!(send(:"current_#{resource_name}").to_key)
    @liked = false
    if params[:post_id].present? and params[:like].present?
      graph = Koala::Facebook::API.new(current_user.access_token)
      @liked = graph.put_like(params[:post_id])
    end
    flag = true
    if params[:user][:current_password].present? and not resource.valid_password?(params[:user][:current_password])
      flag = false
    end
    if flag and resource.update_attributes(params[resource_name])
      if is_navigational_format?
        if params[:current_password].present? and params[:password].present?
          #render :action => "update"
          set_flash_message :notice, flash_key || :updated
        end
        if resource.respond_to?(:pending_reconfirmation?) && resource.pending_reconfirmation?
          #render :action => "update"
          flash_key = :update_needs_confirmation
        end
        set_flash_message :notice, flash_key || :updated
      end
      sign_in resource_name, resource, :bypass => true
      #respond_with resource, :location => after_update_path_for(resource)
      respond_to do |format|
       format.js {}
       format.html {redirect_to user_path(:id => current_user.id)}
     end
    else

      clean_up_passwords resource
      logger.info resource.errors.inspect
      if resource.errors
        render :edit
      else
        respond_with resource
      end
    end
  end

  # DELETE /resource
  def destroy
    resource.destroy
    Devise.sign_out_all_scopes ? sign_out : sign_out(resource_name)
    set_flash_message :notice, :destroyed if is_navigational_format?
    respond_with_navigational(resource){ redirect_to after_sign_out_path_for(resource_name) }
  end

  # GET /resource/cancel
  # Forces the session data which is usually expired after sign
  # in to be expired now. This is useful if the user wants to
  # cancel oauth signing in/up in the middle of the process,
  # removing all OAuth session data.
  def cancel
    expire_session_data_after_sign_in!
    redirect_to new_registration_path(resource_name)
  end

  protected

  def sign_up_params
    devise_parameter_sanitizer.sanitize(:sign_up)
  end

  def account_update_params
    devise_parameter_sanitizer.sanitize(:account_update)
  end

  # Build a devise resource passing in the session. Useful to move
  # temporary session data to the newly created user.
  def build_resource(hash=nil)
    hash ||= params[resource_name] || {}
    self.resource = resource_class.new_with_session(hash, session)
  end

  # The path used after sign up. You need to overwrite this method
  # in your own RegistrationsController.
  def after_sign_up_path_for(resource)
    after_sign_in_path_for(resource)
  end

  # The path used after sign up for inactive accounts. You need to overwrite
  # this method in your own RegistrationsController.
  def after_inactive_sign_up_path_for(resource)
    respond_to?(:root_path) ? root_path : "/"
  end

  # The default url to be used after updating a resource. You need to overwrite
  # this method in your own RegistrationsController.
  def after_update_path_for(resource)
    signed_in_root_path(resource)
  end

  # Authenticates the current scope and gets the current resource from the session.
  def authenticate_scope!
    unless params[:automatic_login].present?
      send(:"authenticate_#{resource_name}!", :force => true)
      self.resource = send(:"current_#{resource_name}")
    end
  end
  def sign_up(resource_name, resource)
    sign_in(resource_name, resource)
  end
end
